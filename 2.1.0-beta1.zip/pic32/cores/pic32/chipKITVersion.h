#ifndef _CHIPKIT_VERSION
#define _CHIPKIT_VERSION

// Version master-v2.1.0
#define __CHIPKIT__ 20100

#endif
