#ifndef _ARDUINO_H
#define _ARDUINO_H

#include <WProgram.h>

#endif
